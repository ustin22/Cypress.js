describe('Автотесты на авторизацию', function () {
    
    it('правильный логин и пароль', function () {
        cy.visit('https://login.qa.studio/');
        cy.get('#mail').type('german@dolnikov.ru'); //ввел логин
        cy.get('#loginButton').should('be.disabled'); //при введении логина кнопка "вход" неактивна
        cy.get('#pass').type('iLoveqastudio1'); //вводим пароль
        cy.get('#loginButton').should('be.enabled'); //при введении логина и пароля кнопка "вход активна"
        cy.get('#loginButton').click(); //нажимаю войти
        cy.get('#messageHeader').should('be.visible'); //текст виден порльзователю
        cy.get('#messageHeader').contains('Авторизация прошла успешно'); //проверяю текст
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); //есть крестик
       })




       it('правильный логин и неправильный пароль', function () {
        cy.visit('https://login.qa.studio/');
        cy.get('#mail').type('german@dolnikov.ru'); //ввел логин
        cy.get('#loginButton').should('be.disabled'); //при введении логина кнопка "вход" неактивна
        cy.get('#pass').type('iLoveqastudio2'); //вводим пароль
        cy.get('#loginButton').should('be.enabled'); //при введении логина и пароля кнопка "вход активна"
        cy.get('#loginButton').click(); //нажимаю войти
        cy.get('#messageHeader').should('be.visible'); //текст видем порльзователю
        cy.get('#messageHeader').contains('Такого логина или пароля нет'); //проверяю текст
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); //есть крестик
       })




       it('проверка валидации', function () {
        cy.visit('https://login.qa.studio/'); //захожу на сайт
        cy.get('#mail').type('germandolnikov.ru'); //ввел логин
        cy.get('#loginButton').should('be.disabled'); //при введении логина кнопка "вход" неактивна
        cy.get('#pass').type('iLoveqastudio2'); //вводим пароль
        cy.get('#loginButton').should('be.enabled'); //при введении логина и пароля кнопка "вход активна"
        cy.get('#loginButton').click(); //нажимаю войти
        cy.get('#messageHeader').should('be.visible'); //текст видем порльзователю
        cy.get('#messageHeader').contains('Нужно исправить проблему валидации'); //проверяю текст
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); //есть крестик
       })




       it('забыл пароль', function () {
        cy.visit('https://login.qa.studio/'); //захожу на сайт
        cy.get('#forgotEmailButton').click(); //нажал забыл пароль
        cy.get('#mailForgot').type('german@dolnikov.ru'); //вводим почту
        cy.get('#restoreEmailButton').click(); //кликнуть на кнопку отправить код
        cy.get('#messageHeader').should('be.visible'); //текст видем порльзователю
        cy.get('#messageHeader').contains('Успешно отправили пароль на e-mail'); //проверяю текст
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); //есть крестик
       })



       
       it('неправильный логин и правильный пароль', function () {
        cy.visit('https://login.qa.studio/');
        cy.get('#mail').type('germ@dolnikov.ru'); //ввел логин
        cy.get('#loginButton').should('be.disabled'); //при введении логина кнопка "вход" неактивна
        cy.get('#pass').type('iLoveqastudio1'); //вводим пароль
        cy.get('#loginButton').should('be.enabled'); //при введении логина и пароля кнопка "вход активна"
        cy.get('#loginButton').click(); //нажимаю войти
        cy.get('#messageHeader').should('be.visible'); //текст виден порльзователю
        cy.get('#messageHeader').contains('Такого логина или пароля нет'); //проверяю текст
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); //есть крестик
       })



       it('приведение к строчным буквам в логине', function () {
        cy.visit('https://login.qa.studio/');
        cy.get('#mail').type('GerMan@Dolnikov.ru'); //ввел логин
        cy.get('#loginButton').should('be.disabled'); //при введении логина кнопка "вход" неактивна
        cy.get('#pass').type('iLoveqastudio1'); //вводим пароль
        cy.get('#loginButton').should('be.enabled'); //при введении логина и пароля кнопка "вход активна"
        cy.get('#loginButton').click(); //нажимаю войти
        cy.get('#messageHeader').should('be.visible'); //текст виден порльзователю
        cy.get('#messageHeader').contains('Авторизация прошла успешно'); //проверяю текст
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); //есть крестик
       })

       
})

        //найди поле логин и напиши в него верный логин
        //найди поле пароли и напиши  внего верный пароль
        //найди кнопку войти и нажми на нее
        //проверить что на странечке есть тектс"Авторизация проша успешно"
        
         

     

