describe('Автотесты на покупку аватара', function (){
    it('e2e тест на покупку нового аватара для тренера', function () {
        cy.visit('https://pokemonbattle.me/'); //заходим на сайт 
        cy.get(':nth-child(1) > .auth__input').type('ustinchashina@yandex.ru'); //ввожу логин
        cy.get('#password').type('Nevergreen2'); //ввожу 
        cy.get('.auth__button').click(); //нажимаю войти
        cy.get('.header__btns > [href="/shop"]').click(); //захожу в магазин
        cy.get('.shop__list > li').not('.feature-empty').children('.shop__button').eq(0).click(); //выбираю каждый раз разный аватар
        cy.get('.pay__payform-v2 > :nth-child(2) > .pay_base-input-v2').type(4444333322221111);
        cy.get(':nth-child(1) > .pay_base-input-v2').type('06/25');
        cy.get('.pay-inputs-box > :nth-child(2) > .pay_base-input-v2').type(125);
        cy.get('.pay__input-box-last-of > .pay_base-input-v2').type('KARTINA MASLOM');
        cy.get('.pay-btn').click();
        cy.get('#cardnumber').type(56456);
        cy.get('.payment__submit-button').click();
        cy.get('.payment__adv').click();   
    })

})